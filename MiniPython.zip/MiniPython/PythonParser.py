# Generated from PythonParser.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,45,174,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,1,0,5,0,20,8,0,10,0,12,0,23,9,0,1,0,1,0,1,1,1,
        1,1,1,1,1,1,1,1,1,1,1,3,1,34,8,1,1,1,3,1,37,8,1,1,2,1,2,1,2,1,2,
        1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,3,2,52,8,2,1,2,1,2,1,2,5,2,57,
        8,2,10,2,12,2,60,9,2,1,3,1,3,1,3,1,3,3,3,66,8,3,1,3,1,3,1,3,1,3,
        1,3,3,3,73,8,3,1,3,1,3,5,3,77,8,3,10,3,12,3,80,9,3,1,3,1,3,1,3,3,
        3,85,8,3,1,3,3,3,88,8,3,1,4,1,4,1,4,1,4,1,4,1,4,1,4,5,4,97,8,4,10,
        4,12,4,100,9,4,3,4,102,8,4,1,4,1,4,1,4,3,4,107,8,4,1,4,1,4,3,4,111,
        8,4,1,4,3,4,114,8,4,1,5,1,5,1,5,1,5,1,5,1,5,1,5,3,5,123,8,5,1,5,
        1,5,1,6,1,6,1,6,1,6,3,6,131,8,6,1,6,1,6,1,7,1,7,1,7,1,7,1,7,1,7,
        1,7,1,7,3,7,143,8,7,1,7,1,7,3,7,147,8,7,1,7,1,7,1,7,3,7,152,8,7,
        1,7,1,7,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,3,8,164,8,8,1,8,1,8,1,8,
        5,8,169,8,8,10,8,12,8,172,9,8,1,8,0,2,4,16,9,0,2,4,6,8,10,12,14,
        16,0,3,2,0,24,24,26,30,1,0,11,12,1,0,18,23,197,0,21,1,0,0,0,2,33,
        1,0,0,0,4,51,1,0,0,0,6,61,1,0,0,0,8,89,1,0,0,0,10,115,1,0,0,0,12,
        126,1,0,0,0,14,134,1,0,0,0,16,163,1,0,0,0,18,20,3,2,1,0,19,18,1,
        0,0,0,20,23,1,0,0,0,21,19,1,0,0,0,21,22,1,0,0,0,22,24,1,0,0,0,23,
        21,1,0,0,0,24,25,5,0,0,1,25,1,1,0,0,0,26,34,3,16,8,0,27,34,3,4,2,
        0,28,34,3,6,3,0,29,34,3,8,4,0,30,34,3,10,5,0,31,34,3,12,6,0,32,34,
        3,14,7,0,33,26,1,0,0,0,33,27,1,0,0,0,33,28,1,0,0,0,33,29,1,0,0,0,
        33,30,1,0,0,0,33,31,1,0,0,0,33,32,1,0,0,0,34,36,1,0,0,0,35,37,5,
        42,0,0,36,35,1,0,0,0,36,37,1,0,0,0,37,3,1,0,0,0,38,39,6,2,-1,0,39,
        52,5,14,0,0,40,52,5,15,0,0,41,42,5,13,0,0,42,52,3,4,2,4,43,44,5,
        34,0,0,44,45,3,4,2,0,45,46,5,35,0,0,46,52,1,0,0,0,47,48,3,16,8,0,
        48,49,7,0,0,0,49,50,3,16,8,0,50,52,1,0,0,0,51,38,1,0,0,0,51,40,1,
        0,0,0,51,41,1,0,0,0,51,43,1,0,0,0,51,47,1,0,0,0,52,58,1,0,0,0,53,
        54,10,3,0,0,54,55,7,1,0,0,55,57,3,4,2,4,56,53,1,0,0,0,57,60,1,0,
        0,0,58,56,1,0,0,0,58,59,1,0,0,0,59,5,1,0,0,0,60,58,1,0,0,0,61,62,
        5,3,0,0,62,63,3,4,2,0,63,65,5,40,0,0,64,66,5,42,0,0,65,64,1,0,0,
        0,65,66,1,0,0,0,66,67,1,0,0,0,67,78,3,2,1,0,68,69,5,5,0,0,69,70,
        3,4,2,0,70,72,5,40,0,0,71,73,5,42,0,0,72,71,1,0,0,0,72,73,1,0,0,
        0,73,74,1,0,0,0,74,75,3,2,1,0,75,77,1,0,0,0,76,68,1,0,0,0,77,80,
        1,0,0,0,78,76,1,0,0,0,78,79,1,0,0,0,79,87,1,0,0,0,80,78,1,0,0,0,
        81,82,5,4,0,0,82,84,5,40,0,0,83,85,5,42,0,0,84,83,1,0,0,0,84,85,
        1,0,0,0,85,86,1,0,0,0,86,88,3,2,1,0,87,81,1,0,0,0,87,88,1,0,0,0,
        88,7,1,0,0,0,89,90,5,1,0,0,90,91,5,33,0,0,91,101,5,34,0,0,92,102,
        5,33,0,0,93,98,5,33,0,0,94,95,5,38,0,0,95,97,5,33,0,0,96,94,1,0,
        0,0,97,100,1,0,0,0,98,96,1,0,0,0,98,99,1,0,0,0,99,102,1,0,0,0,100,
        98,1,0,0,0,101,92,1,0,0,0,101,93,1,0,0,0,102,103,1,0,0,0,103,104,
        5,35,0,0,104,106,5,40,0,0,105,107,5,42,0,0,106,105,1,0,0,0,106,107,
        1,0,0,0,107,108,1,0,0,0,108,110,5,9,0,0,109,111,3,16,8,0,110,109,
        1,0,0,0,110,111,1,0,0,0,111,113,1,0,0,0,112,114,5,42,0,0,113,112,
        1,0,0,0,113,114,1,0,0,0,114,9,1,0,0,0,115,116,5,33,0,0,116,122,5,
        34,0,0,117,123,3,16,8,0,118,119,3,16,8,0,119,120,5,38,0,0,120,121,
        3,16,8,0,121,123,1,0,0,0,122,117,1,0,0,0,122,118,1,0,0,0,122,123,
        1,0,0,0,123,124,1,0,0,0,124,125,5,35,0,0,125,11,1,0,0,0,126,127,
        5,7,0,0,127,128,3,4,2,0,128,130,5,40,0,0,129,131,5,42,0,0,130,129,
        1,0,0,0,130,131,1,0,0,0,131,132,1,0,0,0,132,133,3,2,1,0,133,13,1,
        0,0,0,134,135,5,6,0,0,135,136,5,33,0,0,136,137,5,8,0,0,137,138,5,
        17,0,0,138,139,5,34,0,0,139,142,3,16,8,0,140,141,5,38,0,0,141,143,
        3,16,8,0,142,140,1,0,0,0,142,143,1,0,0,0,143,146,1,0,0,0,144,145,
        5,38,0,0,145,147,3,16,8,0,146,144,1,0,0,0,146,147,1,0,0,0,147,148,
        1,0,0,0,148,149,5,35,0,0,149,151,5,40,0,0,150,152,5,42,0,0,151,150,
        1,0,0,0,151,152,1,0,0,0,152,153,1,0,0,0,153,154,3,2,1,0,154,15,1,
        0,0,0,155,156,6,8,-1,0,156,164,5,33,0,0,157,164,5,31,0,0,158,159,
        5,34,0,0,159,160,3,16,8,0,160,161,5,35,0,0,161,164,1,0,0,0,162,164,
        5,16,0,0,163,155,1,0,0,0,163,157,1,0,0,0,163,158,1,0,0,0,163,162,
        1,0,0,0,164,170,1,0,0,0,165,166,10,3,0,0,166,167,7,2,0,0,167,169,
        3,16,8,4,168,165,1,0,0,0,169,172,1,0,0,0,170,168,1,0,0,0,170,171,
        1,0,0,0,171,17,1,0,0,0,172,170,1,0,0,0,22,21,33,36,51,58,65,72,78,
        84,87,98,101,106,110,113,122,130,142,146,151,163,170
    ]

class PythonParser ( Parser ):

    grammarFileName = "PythonParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'def'", "'class'", "'if'", "'else'", 
                     "'elif'", "'for'", "'while'", "'in'", "'return'", "'print'", 
                     "'and'", "'or'", "'not'", "'True'", "'False'", "'None'", 
                     "'range'", "'+'", "'-'", "'*'", "'**'", "'/'", "'%'", 
                     "'=='", "'='", "'<'", "'>'", "'<='", "'>='", "'!='", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "'('", "')'", 
                     "'['", "']'", "','", "'.'", "':'", "';'" ]

    symbolicNames = [ "<INVALID>", "DEF", "CLASS", "IF", "ELSE", "ELIF", 
                      "FOR", "WHILE", "IN", "RETURN", "PRINT", "AND", "OR", 
                      "NOT", "TRUE", "FALSE", "NONE", "RANGE", "PLUS", "MINUS", 
                      "TIMES", "POWER", "DIVIDE", "MOD", "EQUAL", "ASSIGN", 
                      "LT", "GT", "LE", "GE", "NE", "NUMBER", "STRING", 
                      "ID", "LPAREN", "RPAREN", "LBRACKET", "RBRACKET", 
                      "COMMA", "DOT", "COLON", "SEMI", "NEWLINE", "WS", 
                      "COMMENT", "LINE_JOIN" ]

    RULE_code = 0
    RULE_stat = 1
    RULE_query = 2
    RULE_conditional = 3
    RULE_function = 4
    RULE_function_call = 5
    RULE_while = 6
    RULE_for = 7
    RULE_expr = 8

    ruleNames =  [ "code", "stat", "query", "conditional", "function", "function_call", 
                   "while", "for", "expr" ]

    EOF = Token.EOF
    DEF=1
    CLASS=2
    IF=3
    ELSE=4
    ELIF=5
    FOR=6
    WHILE=7
    IN=8
    RETURN=9
    PRINT=10
    AND=11
    OR=12
    NOT=13
    TRUE=14
    FALSE=15
    NONE=16
    RANGE=17
    PLUS=18
    MINUS=19
    TIMES=20
    POWER=21
    DIVIDE=22
    MOD=23
    EQUAL=24
    ASSIGN=25
    LT=26
    GT=27
    LE=28
    GE=29
    NE=30
    NUMBER=31
    STRING=32
    ID=33
    LPAREN=34
    RPAREN=35
    LBRACKET=36
    RBRACKET=37
    COMMA=38
    DOT=39
    COLON=40
    SEMI=41
    NEWLINE=42
    WS=43
    COMMENT=44
    LINE_JOIN=45

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class CodeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(PythonParser.EOF, 0)

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PythonParser.StatContext)
            else:
                return self.getTypedRuleContext(PythonParser.StatContext,i)


        def getRuleIndex(self):
            return PythonParser.RULE_code

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCode" ):
                return visitor.visitCode(self)
            else:
                return visitor.visitChildren(self)




    def code(self):

        localctx = PythonParser.CodeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_code)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 21
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 27917410506) != 0):
                self.state = 18
                self.stat()
                self.state = 23
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 24
            self.match(PythonParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self):
            return self.getTypedRuleContext(PythonParser.ExprContext,0)


        def query(self):
            return self.getTypedRuleContext(PythonParser.QueryContext,0)


        def conditional(self):
            return self.getTypedRuleContext(PythonParser.ConditionalContext,0)


        def function(self):
            return self.getTypedRuleContext(PythonParser.FunctionContext,0)


        def function_call(self):
            return self.getTypedRuleContext(PythonParser.Function_callContext,0)


        def while_(self):
            return self.getTypedRuleContext(PythonParser.WhileContext,0)


        def for_(self):
            return self.getTypedRuleContext(PythonParser.ForContext,0)


        def NEWLINE(self):
            return self.getToken(PythonParser.NEWLINE, 0)

        def getRuleIndex(self):
            return PythonParser.RULE_stat

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStat" ):
                return visitor.visitStat(self)
            else:
                return visitor.visitChildren(self)




    def stat(self):

        localctx = PythonParser.StatContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_stat)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 33
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.state = 26
                self.expr(0)
                pass

            elif la_ == 2:
                self.state = 27
                self.query(0)
                pass

            elif la_ == 3:
                self.state = 28
                self.conditional()
                pass

            elif la_ == 4:
                self.state = 29
                self.function()
                pass

            elif la_ == 5:
                self.state = 30
                self.function_call()
                pass

            elif la_ == 6:
                self.state = 31
                self.while_()
                pass

            elif la_ == 7:
                self.state = 32
                self.for_()
                pass


            self.state = 36
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
            if la_ == 1:
                self.state = 35
                self.match(PythonParser.NEWLINE)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class QueryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.op = None # Token

        def TRUE(self):
            return self.getToken(PythonParser.TRUE, 0)

        def FALSE(self):
            return self.getToken(PythonParser.FALSE, 0)

        def NOT(self):
            return self.getToken(PythonParser.NOT, 0)

        def query(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PythonParser.QueryContext)
            else:
                return self.getTypedRuleContext(PythonParser.QueryContext,i)


        def LPAREN(self):
            return self.getToken(PythonParser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(PythonParser.RPAREN, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PythonParser.ExprContext)
            else:
                return self.getTypedRuleContext(PythonParser.ExprContext,i)


        def LT(self):
            return self.getToken(PythonParser.LT, 0)

        def GT(self):
            return self.getToken(PythonParser.GT, 0)

        def LE(self):
            return self.getToken(PythonParser.LE, 0)

        def GE(self):
            return self.getToken(PythonParser.GE, 0)

        def EQUAL(self):
            return self.getToken(PythonParser.EQUAL, 0)

        def NE(self):
            return self.getToken(PythonParser.NE, 0)

        def AND(self):
            return self.getToken(PythonParser.AND, 0)

        def OR(self):
            return self.getToken(PythonParser.OR, 0)

        def getRuleIndex(self):
            return PythonParser.RULE_query

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitQuery" ):
                return visitor.visitQuery(self)
            else:
                return visitor.visitChildren(self)



    def query(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = PythonParser.QueryContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 4
        self.enterRecursionRule(localctx, 4, self.RULE_query, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 51
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
            if la_ == 1:
                self.state = 39
                self.match(PythonParser.TRUE)
                pass

            elif la_ == 2:
                self.state = 40
                self.match(PythonParser.FALSE)
                pass

            elif la_ == 3:
                self.state = 41
                self.match(PythonParser.NOT)
                self.state = 42
                self.query(4)
                pass

            elif la_ == 4:
                self.state = 43
                self.match(PythonParser.LPAREN)
                self.state = 44
                self.query(0)
                self.state = 45
                self.match(PythonParser.RPAREN)
                pass

            elif la_ == 5:
                self.state = 47
                self.expr(0)
                self.state = 48
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 2097152000) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 49
                self.expr(0)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 58
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,4,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = PythonParser.QueryContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_query)
                    self.state = 53
                    if not self.precpred(self._ctx, 3):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                    self.state = 54
                    localctx.op = self._input.LT(1)
                    _la = self._input.LA(1)
                    if not(_la==11 or _la==12):
                        localctx.op = self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 55
                    self.query(4) 
                self.state = 60
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,4,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class ConditionalContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(PythonParser.IF, 0)

        def query(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PythonParser.QueryContext)
            else:
                return self.getTypedRuleContext(PythonParser.QueryContext,i)


        def COLON(self, i:int=None):
            if i is None:
                return self.getTokens(PythonParser.COLON)
            else:
                return self.getToken(PythonParser.COLON, i)

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PythonParser.StatContext)
            else:
                return self.getTypedRuleContext(PythonParser.StatContext,i)


        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(PythonParser.NEWLINE)
            else:
                return self.getToken(PythonParser.NEWLINE, i)

        def ELIF(self, i:int=None):
            if i is None:
                return self.getTokens(PythonParser.ELIF)
            else:
                return self.getToken(PythonParser.ELIF, i)

        def ELSE(self):
            return self.getToken(PythonParser.ELSE, 0)

        def getRuleIndex(self):
            return PythonParser.RULE_conditional

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConditional" ):
                return visitor.visitConditional(self)
            else:
                return visitor.visitChildren(self)




    def conditional(self):

        localctx = PythonParser.ConditionalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_conditional)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 61
            self.match(PythonParser.IF)
            self.state = 62
            self.query(0)
            self.state = 63
            self.match(PythonParser.COLON)
            self.state = 65
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==42:
                self.state = 64
                self.match(PythonParser.NEWLINE)


            self.state = 67
            self.stat()
            self.state = 78
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,7,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 68
                    self.match(PythonParser.ELIF)
                    self.state = 69
                    self.query(0)
                    self.state = 70
                    self.match(PythonParser.COLON)
                    self.state = 72
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if _la==42:
                        self.state = 71
                        self.match(PythonParser.NEWLINE)


                    self.state = 74
                    self.stat() 
                self.state = 80
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,7,self._ctx)

            self.state = 87
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,9,self._ctx)
            if la_ == 1:
                self.state = 81
                self.match(PythonParser.ELSE)
                self.state = 82
                self.match(PythonParser.COLON)
                self.state = 84
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==42:
                    self.state = 83
                    self.match(PythonParser.NEWLINE)


                self.state = 86
                self.stat()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DEF(self):
            return self.getToken(PythonParser.DEF, 0)

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(PythonParser.ID)
            else:
                return self.getToken(PythonParser.ID, i)

        def LPAREN(self):
            return self.getToken(PythonParser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(PythonParser.RPAREN, 0)

        def COLON(self):
            return self.getToken(PythonParser.COLON, 0)

        def RETURN(self):
            return self.getToken(PythonParser.RETURN, 0)

        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(PythonParser.NEWLINE)
            else:
                return self.getToken(PythonParser.NEWLINE, i)

        def expr(self):
            return self.getTypedRuleContext(PythonParser.ExprContext,0)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(PythonParser.COMMA)
            else:
                return self.getToken(PythonParser.COMMA, i)

        def getRuleIndex(self):
            return PythonParser.RULE_function

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunction" ):
                return visitor.visitFunction(self)
            else:
                return visitor.visitChildren(self)




    def function(self):

        localctx = PythonParser.FunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_function)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 89
            self.match(PythonParser.DEF)
            self.state = 90
            self.match(PythonParser.ID)
            self.state = 91
            self.match(PythonParser.LPAREN)
            self.state = 101
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,11,self._ctx)
            if la_ == 1:
                self.state = 92
                self.match(PythonParser.ID)
                pass

            elif la_ == 2:
                self.state = 93
                self.match(PythonParser.ID)
                self.state = 98
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==38:
                    self.state = 94
                    self.match(PythonParser.COMMA)
                    self.state = 95
                    self.match(PythonParser.ID)
                    self.state = 100
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                pass


            self.state = 103
            self.match(PythonParser.RPAREN)
            self.state = 104
            self.match(PythonParser.COLON)
            self.state = 106
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==42:
                self.state = 105
                self.match(PythonParser.NEWLINE)


            self.state = 108
            self.match(PythonParser.RETURN)
            self.state = 110
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,13,self._ctx)
            if la_ == 1:
                self.state = 109
                self.expr(0)


            self.state = 113
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,14,self._ctx)
            if la_ == 1:
                self.state = 112
                self.match(PythonParser.NEWLINE)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Function_callContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(PythonParser.ID, 0)

        def LPAREN(self):
            return self.getToken(PythonParser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(PythonParser.RPAREN, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PythonParser.ExprContext)
            else:
                return self.getTypedRuleContext(PythonParser.ExprContext,i)


        def COMMA(self):
            return self.getToken(PythonParser.COMMA, 0)

        def getRuleIndex(self):
            return PythonParser.RULE_function_call

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunction_call" ):
                return visitor.visitFunction_call(self)
            else:
                return visitor.visitChildren(self)




    def function_call(self):

        localctx = PythonParser.Function_callContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_function_call)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 115
            self.match(PythonParser.ID)
            self.state = 116
            self.match(PythonParser.LPAREN)
            self.state = 122
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,15,self._ctx)
            if la_ == 1:
                self.state = 117
                self.expr(0)

            elif la_ == 2:
                self.state = 118
                self.expr(0)
                self.state = 119
                self.match(PythonParser.COMMA)
                self.state = 120
                self.expr(0)


            self.state = 124
            self.match(PythonParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class WhileContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WHILE(self):
            return self.getToken(PythonParser.WHILE, 0)

        def query(self):
            return self.getTypedRuleContext(PythonParser.QueryContext,0)


        def COLON(self):
            return self.getToken(PythonParser.COLON, 0)

        def stat(self):
            return self.getTypedRuleContext(PythonParser.StatContext,0)


        def NEWLINE(self):
            return self.getToken(PythonParser.NEWLINE, 0)

        def getRuleIndex(self):
            return PythonParser.RULE_while

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWhile" ):
                return visitor.visitWhile(self)
            else:
                return visitor.visitChildren(self)




    def while_(self):

        localctx = PythonParser.WhileContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_while)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 126
            self.match(PythonParser.WHILE)
            self.state = 127
            self.query(0)
            self.state = 128
            self.match(PythonParser.COLON)
            self.state = 130
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==42:
                self.state = 129
                self.match(PythonParser.NEWLINE)


            self.state = 132
            self.stat()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ForContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FOR(self):
            return self.getToken(PythonParser.FOR, 0)

        def ID(self):
            return self.getToken(PythonParser.ID, 0)

        def IN(self):
            return self.getToken(PythonParser.IN, 0)

        def RANGE(self):
            return self.getToken(PythonParser.RANGE, 0)

        def LPAREN(self):
            return self.getToken(PythonParser.LPAREN, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PythonParser.ExprContext)
            else:
                return self.getTypedRuleContext(PythonParser.ExprContext,i)


        def RPAREN(self):
            return self.getToken(PythonParser.RPAREN, 0)

        def COLON(self):
            return self.getToken(PythonParser.COLON, 0)

        def stat(self):
            return self.getTypedRuleContext(PythonParser.StatContext,0)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(PythonParser.COMMA)
            else:
                return self.getToken(PythonParser.COMMA, i)

        def NEWLINE(self):
            return self.getToken(PythonParser.NEWLINE, 0)

        def getRuleIndex(self):
            return PythonParser.RULE_for

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFor" ):
                return visitor.visitFor(self)
            else:
                return visitor.visitChildren(self)




    def for_(self):

        localctx = PythonParser.ForContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_for)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 134
            self.match(PythonParser.FOR)
            self.state = 135
            self.match(PythonParser.ID)
            self.state = 136
            self.match(PythonParser.IN)
            self.state = 137
            self.match(PythonParser.RANGE)
            self.state = 138
            self.match(PythonParser.LPAREN)
            self.state = 139
            self.expr(0)
            self.state = 142
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,17,self._ctx)
            if la_ == 1:
                self.state = 140
                self.match(PythonParser.COMMA)
                self.state = 141
                self.expr(0)


            self.state = 146
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==38:
                self.state = 144
                self.match(PythonParser.COMMA)
                self.state = 145
                self.expr(0)


            self.state = 148
            self.match(PythonParser.RPAREN)
            self.state = 149
            self.match(PythonParser.COLON)
            self.state = 151
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==42:
                self.state = 150
                self.match(PythonParser.NEWLINE)


            self.state = 153
            self.stat()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(PythonParser.ID, 0)

        def NUMBER(self):
            return self.getToken(PythonParser.NUMBER, 0)

        def LPAREN(self):
            return self.getToken(PythonParser.LPAREN, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PythonParser.ExprContext)
            else:
                return self.getTypedRuleContext(PythonParser.ExprContext,i)


        def RPAREN(self):
            return self.getToken(PythonParser.RPAREN, 0)

        def NONE(self):
            return self.getToken(PythonParser.NONE, 0)

        def PLUS(self):
            return self.getToken(PythonParser.PLUS, 0)

        def MINUS(self):
            return self.getToken(PythonParser.MINUS, 0)

        def TIMES(self):
            return self.getToken(PythonParser.TIMES, 0)

        def DIVIDE(self):
            return self.getToken(PythonParser.DIVIDE, 0)

        def MOD(self):
            return self.getToken(PythonParser.MOD, 0)

        def POWER(self):
            return self.getToken(PythonParser.POWER, 0)

        def getRuleIndex(self):
            return PythonParser.RULE_expr

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr" ):
                return visitor.visitExpr(self)
            else:
                return visitor.visitChildren(self)



    def expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = PythonParser.ExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 16
        self.enterRecursionRule(localctx, 16, self.RULE_expr, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 163
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [33]:
                self.state = 156
                self.match(PythonParser.ID)
                pass
            elif token in [31]:
                self.state = 157
                self.match(PythonParser.NUMBER)
                pass
            elif token in [34]:
                self.state = 158
                self.match(PythonParser.LPAREN)
                self.state = 159
                self.expr(0)
                self.state = 160
                self.match(PythonParser.RPAREN)
                pass
            elif token in [16]:
                self.state = 162
                self.match(PythonParser.NONE)
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 170
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,21,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = PythonParser.ExprContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                    self.state = 165
                    if not self.precpred(self._ctx, 3):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                    self.state = 166
                    _la = self._input.LA(1)
                    if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 16515072) != 0)):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 167
                    self.expr(4) 
                self.state = 172
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,21,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[2] = self.query_sempred
        self._predicates[8] = self.expr_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def query_sempred(self, localctx:QueryContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 3)
         

    def expr_sempred(self, localctx:ExprContext, predIndex:int):
            if predIndex == 1:
                return self.precpred(self._ctx, 3)
         




