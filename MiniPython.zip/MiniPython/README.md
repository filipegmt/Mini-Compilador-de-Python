# minipython
Mini compilador de Python

Teste de PYTHON